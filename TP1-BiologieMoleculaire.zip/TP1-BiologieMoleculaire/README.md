# TP1 – M1 Biologie Moléculaire et Cellulaire  
## Comment déposer un projet directement sur GitHub

---

## 🎯 Objectif du TP
Ce TP a pour but d’apprendre à **publier un projet directement sur GitHub**, sans utiliser le logiciel Git.  
Il permet aussi d’intégrer un contenu scientifique simple en biologie moléculaire.

---

## 📂 Contenu du projet
- `structure_ADN.txt` : résumé sur la structure et la composition de l’ADN  
- `calcul_GC.py` : script Python qui calcule le pourcentage de bases G et C dans une séquence d’ADN  
- `README.md` : ce fichier de description

---

## 🧠 Description du travail
1. Création d’un dépôt GitHub public  
2. Importation des fichiers du projet  
3. Ajout d’un fichier `README.md` clair et structuré  
4. Vérification du bon affichage sur GitHub  
5. Envoi du lien du dépôt à **D.AAID**

---

## ✅ Résultat du code Python
Exemple de sortie du programme `calcul_GC.py` :

```
Séquence : ATGCGCGTTAACG
Pourcentage de GC : 53.85 %
```

---

## 👩‍💻 Auteur
**Nom :** MEGAACHE Salsabil  
**Spécialité :** M1 Biologie Moléculaire et Cellulaire  
**Université :** Université Batna 2  
**Année universitaire :** 2025/2026  

---

## 🔗 Lien du dépôt
👉 [Ajoutez ici le lien GitHub de votre projet]
