# TP1 – M1 Biologie Moléculaire et Cellulaire  
## Sujet : Calcul du pourcentage de bases G et C dans une séquence d'ADN

---

### 🎯 Objectif
Ce TP vise à apprendre à **publier un projet sur GitHub** et à créer un petit programme en Python
qui calcule le pourcentage de bases G et C dans une séquence d’ADN.

---

### 📁 Contenu du projet
- `calcul_GC.py` → Script Python pour le calcul du %GC  
- `structure_ADN.txt` → Exemple de séquence ADN  
- `README.md` → Description du projet

---

### 🧬 Exemple de résultat
```bash
Séquence : ATGCGCGTTAACG
Pourcentage de GC : 53.85 %
```

---

### 👩‍💻 Auteur
**Nom :** MEGAACHE Salsabil  
**Spécialité :** M1 Biologie Moléculaire et Cellulaire  
**Université :** Université Batna 2  
**Année universitaire :** 2025/2026
