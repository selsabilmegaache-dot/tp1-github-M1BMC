# TP1 - M1 Biologie Moléculaire et Cellulaire
# Auteur : MEGAACHE Salsabil
# Description : Calcul du pourcentage de bases G et C dans une séquence d'ADN

def pourcentage_GC(sequence):
    """Calcule le pourcentage de G et C dans une séquence d'ADN."""
    sequence = sequence.upper()  # pour éviter les erreurs de casse
    longueur = len(sequence)
    if longueur == 0:
        return 0
    gc = sequence.count("G") + sequence.count("C")
    return (gc / longueur) * 100

# Exemple d'utilisation
sequence_exemple = "ATGCGCGTTAACG"
gc_percent = pourcentage_GC(sequence_exemple)

print("Séquence :", sequence_exemple)
print("Pourcentage de GC :", round(gc_percent, 2), "%")
